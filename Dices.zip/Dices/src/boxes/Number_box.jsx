import React, { useState } from "react";
import styled from "styled-components";

const NumberBox = ({selectNum,setSelectNum}) => {
  const boxes = [1, 2, 3, 4, 5, 6];

  
  console.log(selectNum);
  return (
    <>
      <SelectorBox>
        <div className="flex">
          {boxes.map((value, i) => (
            <Box
              isSelected={value === selectNum}
              key={i}
              onClick={() => setSelectNum(value)}
            >
              {value}
            </Box>
          ))}
        </div>
      </SelectorBox>
    </>
  );
};

const SelectorBox = styled.div`
  .flex {
    display: flex;
    gap: 24px;
  }
`;

const Box = styled.div`
  display: flex;
  height: 50px;
  width: 50px;
  justify-content: center;
  align-items: center;
  border: 1px solid black;
  background-color: ${(props) => (props.isSelected ? "black" : "white")};
  color: ${(props) => (!props.isSelected ? "black" : "white")};
`;

export default NumberBox;
