import React from "react";
import Number_box from "../boxes/Number_box";
import Score from "../components/Score";
import { useState } from "react";
import Roll_dice from "../components/Roll_dice";


const Sec_slide = () => {
  const [ans,SetAns] = useState(0)
  const [selectNum, setSelectNum] = useState(null);
  const [diceCurrent, setDiceCurrent] = useState(1);

  const randomDice = (min, max) => {
    return Math.floor(Math.random() * (max - min + 1) + min); // Random number generate karne ka logic thik kiya gaya hai
}

const rollDice = () => {
    const randomNum = randomDice(1, 6); // Random number generate karne ke liye sahi parameter pass kiya gaya hai
    setDiceCurrent(randomNum); // setDiceCurrent function ka parameter name theek kiya gaya hai

    if(!selectNum) return;
    if(selectNum === randomNum){
      SetAns((prev) => prev +  randomNum)
    }else{
      SetAns((prev) => prev - 2)
    }

    setSelectNum(undefined)
}
const resetScore = () => {
  SetAns(0);
};
  return (
    <div>
      <div className="row">
        <div className="col-md-6">
         <Score ans ={ans}/>
        </div>
        <div className="col-md-6">
         <Number_box selectNum={selectNum}  setSelectNum={setSelectNum}/>
        </div>
        <div className="col-md-12"></div>
       <Roll_dice diceCurrent={diceCurrent} rollDice={rollDice} />
      </div>
    </div>
  );
};

export default Sec_slide;
