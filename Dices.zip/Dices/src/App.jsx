
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css'
import Structure from './components/Structure';
import { useState } from 'react';
import Sec_slide from './sec_slide/Sec_slide';

function App() {
  
const [gameStart , setGameStart] = useState(false)

const toggleGame = () =>{
  setGameStart((prev) => !(prev))
}

  return (
    <>
    {gameStart ?  <Sec_slide/> : <Structure toggle = {toggleGame}/> }
    
      
    </>
  )
}

export default App
