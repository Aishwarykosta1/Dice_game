import React, { useState } from 'react';

const Roll_dice = ({diceCurrent,rollDice}) => {
    // Initial value 1 ke saath useState ka use kiya gaya hai

   
    return (
        <div>
            <div onClick={rollDice}>
                <img src={`./Images/Dices/dice_${diceCurrent}.png`}/>
            </div>
        </div>
    );
}

export default Roll_dice;
