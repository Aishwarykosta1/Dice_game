import React from 'react'

const Score = ({ans}) => {
  return (
    <div>
    <h1>{ans}</h1>
    <p>Total Score</p>
    </div>
  )
}

export default Score
