import React from "react";

import Button from 'react-bootstrap/Button';
const Structure = ({toggle}) => {
  return (
    <div>
      <div className="row">
        <div className="col-md-6">
          <img src="./Images/dices 1.png" />
        </div>
        <div className="col-md-6">
        <h1>DICE GAME</h1>
        <Button onClick={toggle}  variant="dark" >PLAY GAME</Button>
        </div>
      </div>
    </div>
  );
};

export default Structure;
